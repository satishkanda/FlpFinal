import { Component, OnInit } from '@angular/core';
import { ImageService } from 'src/app/imageupload/image.service';
import { Image } from '../Image';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-get-image',
  templateUrl: './get-image.component.html',
  styleUrls: ['./get-image.component.css']
})
export class GetImageComponent implements OnInit {
  images: String[];
  constructor(private service: ImageService) { }

  ngOnInit() {

  }
  onSubmit(value) {
    console.log(value);
    this.service.getImage(value).subscribe(data => {
      this.images = data;
      for(let i =0;i<this.images.length;i++){
          this.images[i] = "http://localhost:5000/images/"+this.images[i];
      }
      console.log(this.images);
    });

  }
}
