import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ImageuploadComponent } from './imageupload/imageupload.component';
import { GetImageComponent } from './image/get-image/get-image.component';

const routes: Routes = [
  {
    path:'',component:ImageuploadComponent   
  },
  {path:'get',component:GetImageComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
