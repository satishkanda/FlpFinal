import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Image } from '../image/Image';

@Injectable({
  providedIn: 'root'
})
export class ImageService {
  image:Image; 
  
  constructor(private http: HttpClient) {
   
  }
        

  uploadImage(formData,productId){
    this.http.post('http://localhost:5001/api/files/'+productId, formData).subscribe(data=>{
      console.log(data);
    })
  }
  getImage(value):Observable<any[]> {
     return this.http.get<any[]>("http://localhost:5001/get/"+value.imageId);
  }
}
