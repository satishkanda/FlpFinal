import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ImageService } from './image.service';

@Component({
  selector: 'app-imageupload',
  templateUrl: './imageupload.component.html',
  styleUrls: ['./imageupload.component.css']
})
export class ImageuploadComponent implements OnInit {


  fileData: File = null;
  constructor(private http: HttpClient,private imageService:ImageService) { }

  ngOnInit() {
  }

  onFileSelected(event) {
    if(event.target.files.length > 0) 
     {
       //console.log(event.target.files[0].name);
       this.fileData = event.target.files[0];
        console.log(this.fileData.name);
     }
   }

  onSubmit() {
    const formData = new FormData();
    formData.append('file', this.fileData);
    this.imageService.uploadImage(formData,1000);

  }
}
