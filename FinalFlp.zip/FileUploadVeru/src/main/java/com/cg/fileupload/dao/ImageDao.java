package com.cg.fileupload.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.fileupload.beans.Images;
@Repository
public interface ImageDao extends JpaRepository<Images, Integer> {
	@Query("select imageUrl from Images where productId=:productId")
	public List<String> getAllProductImages(@PathVariable("productId") int productId);
}
