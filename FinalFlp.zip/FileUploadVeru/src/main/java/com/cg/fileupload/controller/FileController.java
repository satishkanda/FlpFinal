package com.cg.fileupload.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.fileupload.beans.Images;
import com.cg.fileupload.service.FileService;

@RestController
@CrossOrigin("http://localhost:4200")

public class FileController {
	@Autowired
	private FileService fileService;

	@PostMapping(value = "/api/files/{productId}")
	public Images handleFileUpload(@RequestParam("file") MultipartFile file, @PathVariable("productId") int productId)
			throws IOException {
		return fileService.storeFile(file, productId);
	}

	@GetMapping(value = "/get/{productId}")
	public List<String> getImage(@PathVariable("productId") int productId) {
		return fileService.getImage(productId);

	}

}